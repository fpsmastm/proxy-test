import { Settings } from '../types';

const SEARCH_ENGINES: Record<string, string> = {
  google: 'https://www.google.com/search?q=',
  bing: 'https://www.bing.com/search?q=',
  duckduckgo: 'https://duckduckgo.com/?q=',
  brave: 'https://search.brave.com/search?q=',
};

const PROXY_PREFIXES: Record<string, string> = {
  alloy: 'https://api.allorigins.win/raw?url=',
  corrosion: 'https://api.codetabs.com/v1/proxy?quest=',
  worker: '', // uses customProxyUrl
  direct: '',
};

export function isUrl(input: string): boolean {
  const urlPattern = /^(https?:\/\/)?[\w.-]+\.[a-z]{2,}(\/\S*)?$/i;
  return urlPattern.test(input.trim());
}

export function normalizeUrl(input: string): string {
  let url = input.trim();
  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    url = 'https://' + url;
  }
  return url;
}

export function buildProxyUrl(targetUrl: string, settings: Settings): string {
  const normalized = normalizeUrl(targetUrl);

  // If using worker mode and custom proxy URL is set
  if (settings.proxyService === 'worker' && settings.customProxyUrl) {
    return settings.customProxyUrl.replace('{url}', encodeURIComponent(normalized));
  }

  // If custom proxy URL is set (override any mode)
  if (settings.customProxyUrl && settings.proxyService !== 'direct') {
    return settings.customProxyUrl.replace('{url}', encodeURIComponent(normalized));
  }

  const prefix = PROXY_PREFIXES[settings.proxyService] || '';
  if (!prefix) {
    return normalized;
  }

  return prefix + encodeURIComponent(normalized);
}

export function processInput(input: string, settings: Settings): string {
  const trimmed = input.trim();

  if (!trimmed) return '';

  if (isUrl(trimmed)) {
    return normalizeUrl(trimmed);
  }

  // Treat as search query
  const engine = SEARCH_ENGINES[settings.searchEngine] || SEARCH_ENGINES.google;
  return engine + encodeURIComponent(trimmed);
}

export function extractDomain(url: string): string {
  try {
    const parsed = new URL(url.startsWith('http') ? url : 'https://' + url);
    return parsed.hostname;
  } catch {
    return url;
  }
}

export function getFaviconUrl(url: string): string {
  const domain = extractDomain(url);
  return `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
}
