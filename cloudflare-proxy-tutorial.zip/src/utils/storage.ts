import { Bookmark, HistoryEntry, Settings } from '../types';

const STORAGE_KEYS = {
  bookmarks: 'nova_bookmarks',
  history: 'nova_history',
  settings: 'nova_settings',
};

const DEFAULT_SETTINGS: Settings = {
  proxyService: 'direct',
  customProxyUrl: '',
  cloakTitle: '',
  cloakIcon: '',
  cloakEnabled: false,
  searchEngine: 'google',
  aboutBlankCloak: false,
};

export function loadBookmarks(): Bookmark[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.bookmarks);
    return data ? JSON.parse(data) : getDefaultBookmarks();
  } catch {
    return getDefaultBookmarks();
  }
}

export function saveBookmarks(bookmarks: Bookmark[]): void {
  localStorage.setItem(STORAGE_KEYS.bookmarks, JSON.stringify(bookmarks));
}

export function loadHistory(): HistoryEntry[] {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.history);
    return data ? JSON.parse(data) : [];
  } catch {
    return [];
  }
}

export function saveHistory(history: HistoryEntry[]): void {
  localStorage.setItem(STORAGE_KEYS.history, JSON.stringify(history));
}

export function loadSettings(): Settings {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.settings);
    return data ? { ...DEFAULT_SETTINGS, ...JSON.parse(data) } : DEFAULT_SETTINGS;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: Settings): void {
  localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(settings));
}

function getDefaultBookmarks(): Bookmark[] {
  return [
    { id: '1', title: 'Google', url: 'https://www.google.com', favicon: '' },
    { id: '2', title: 'YouTube', url: 'https://www.youtube.com', favicon: '' },
    { id: '3', title: 'Wikipedia', url: 'https://www.wikipedia.org', favicon: '' },
    { id: '4', title: 'Reddit', url: 'https://www.reddit.com', favicon: '' },
  ];
}
